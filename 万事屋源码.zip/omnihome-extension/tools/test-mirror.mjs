#!/usr/bin/env node
/* ============================================================
   镜像规划器离线测试（无需浏览器）
   通过 data: URL 动态载入 ESM 源码，避免在插件目录里塞 package.json。
   用法：node tools/test-mirror.mjs
   ============================================================ */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(HERE, '..', 'src', 'lib', 'mirror.js');

/* data: URL 会被当作 ES module 解析，且不依赖所在目录的 package.json */
const code = fs.readFileSync(SRC, 'utf8');
const { planMirror, normUrl, ROOT } =
  await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));

/* ---------- 迷你断言 ---------- */
let pass = 0, fail = 0;
const results = [];
function ok(name, cond, extra = '') {
  if (cond) { pass++; results.push('  ✓ ' + name); }
  else { fail++; results.push('  ✗ ' + name + (extra ? '  → ' + extra : '')); }
}
function eq(name, actual, expected) {
  const a = JSON.stringify(actual), e = JSON.stringify(expected);
  ok(name, a === e, `实际 ${a} / 期望 ${e}`);
}

/* ---------- chrome.bookmarks 语义仿真 ---------- */
const clone = o => JSON.parse(JSON.stringify(o));

function simulate(initialChildren, ops, folderMap = {}, bmMap = {}) {
  let nid = 9000;
  const root = { id: '__ROOT__', title: 'ROOT', children: clone(initialChildren) };
  const ids = new Map([[ROOT, '__ROOT__']]);
  /* 与 sync.js 的 applyMirror 一致：预置「已存在且无需改动」的节点 */
  for (const [catId, nodeId] of Object.entries(folderMap)) if (nodeId) ids.set('cat:' + catId, nodeId);
  for (const [bmId, nodeId] of Object.entries(bmMap)) if (nodeId) ids.set('bm:' + bmId, nodeId);

  const findNode = (id, node = root) => {
    if (node.id === id) return node;
    for (const c of node.children || []) { const r = findNode(id, c); if (r) return r; }
    return null;
  };
  const findParent = (id, node = root) => {
    for (const c of node.children || []) {
      if (c.id === id) return node;
      const r = findParent(id, c);
      if (r) return r;
    }
    return null;
  };
  const detach = id => {
    const p = findParent(id);
    if (!p) return null;
    const i = p.children.findIndex(c => c.id === id);
    return i >= 0 ? p.children.splice(i, 1)[0] : null;
  };

  for (const o of ops) {
    switch (o.op) {
      case 'createFolder': {
        const n = { id: 'n' + (++nid), title: o.title, children: [] };
        root.children.push(n); ids.set(o.key, n.id); break;
      }
      case 'create': {
        const p = o.parentKey === ROOT ? root : findNode(ids.get(o.parentKey));
        if (!p) break;
        const n = { id: 'n' + (++nid), title: o.title, url: o.url };
        (p.children = p.children || []).push(n); ids.set(o.key, n.id); break;
      }
      case 'rename': {
        const n = findNode(o.nodeId);
        if (n) { n.title = o.title; ids.set(o.key, n.id); }
        break;
      }
      case 'update': {
        const n = findNode(o.nodeId);
        if (n) { n.title = o.title; n.url = o.url; ids.set(o.key, n.id); }
        break;
      }
      case 'move': {
        const node = findNode(o.nodeId || ids.get(o.key));
        const p = o.parentKey === ROOT ? root : findNode(ids.get(o.parentKey));
        if (!node || !p) break;
        detach(node.id);
        p.children = p.children || [];
        p.children.splice(Math.min(o.index, p.children.length), 0, node);
        ids.set(o.key, node.id);
        break;
      }
      case 'remove': detach(o.nodeId); break;
      default: break;
    }
  }
  return root.children;
}

/* ---------- 辅助 ---------- */
const CATS = [
  { id: 'all', name: '全部' },
  { id: 'common', name: '常用' },
  { id: 'dev', name: '开发' },
  { id: 'none', name: '未分类' },
];
const folder = (tree, title) => (tree || []).find(n => !n.url && n.title === title);
const titles = node => node ? (node.children || []).map(c => c.title) : null;
const countOps = (ops, op) => ops.filter(o => o.op === op).length;

/** 连续跑两轮并返回第二轮结果，用于验证幂等 */
function mirrorTwice(children, bookmarks, cats = CATS) {
  const p1 = planMirror({ cats, bookmarks, rootChildren: children, folderMap: {}, bmMap: {} });
  const t1 = simulate(children, p1.ops);
  const p2 = planMirror({ cats, bookmarks, rootChildren: t1, folderMap: p1.folderMap, bmMap: p1.bmMap });
  return { p1, t1, p2, t2: simulate(t1, p2.ops) };
}

/* ============================================================
   用例
   ============================================================ */
console.log('\n镜像规划器测试\n' + '─'.repeat(46));

/* 1. 首次同步：空目录 → 建成完整镜像 */
{
  const bms = [
    { id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 },
    { id: 'b2', name: 'B站', url: 'https://bilibili.com', cat: 'common', order: 0 },
    { id: 'b3', name: 'Google', url: 'https://google.com', cat: 'common', order: 1 },
  ];
  const { t1 } = mirrorTwice([], bms);
  eq('1. 分类文件夹按 OmniHome 顺序建立',
    t1.filter(n => !n.url).map(n => n.title), ['常用', '开发', '未分类']);
  eq('2. 常用分类内书签按 order 排列', titles(folder(t1, '常用')), ['B站', 'Google']);
  eq('3. 开发分类内容', titles(folder(t1, '开发')), ['GitHub']);
  eq('4. 未分类为空', titles(folder(t1, '未分类')), []);
}

/* 2. 幂等：无变化时第二轮不产生增删 */
{
  const bms = [
    { id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 },
    { id: 'b2', name: 'B站', url: 'https://bilibili.com', cat: 'common', order: 0 },
  ];
  const { p2 } = mirrorTwice([], bms);
  eq('5. 二次同步零新建', countOps(p2.ops, 'create') + countOps(p2.ops, 'createFolder'), 0);
  eq('6. 二次同步零删除', countOps(p2.ops, 'remove'), 0);
  eq('7. 二次同步零更新', countOps(p2.ops, 'update') + countOps(p2.ops, 'rename'), 0);
}

/* 3. 重命名书签 → update，且不重建节点 */
{
  const bms = [{ id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 }];
  const { p1, t1 } = mirrorTwice([], bms);
  const idBefore = folder(t1, '开发').children[0].id;
  const p = planMirror({
    cats: CATS, rootChildren: t1, folderMap: p1.folderMap, bmMap: p1.bmMap,
    bookmarks: [{ ...bms[0], name: 'GitHub 新版' }],
  });
  const t = simulate(t1, p.ops);
  eq('8. 重命名产生 update 而非重建', countOps(p.ops, 'update'), 1);
  eq('9. 重命名后标题生效', titles(folder(t, '开发')), ['GitHub 新版']);
  eq('10. 重命名复用同一节点', folder(t, '开发').children[0].id, idBefore);
}

/* 4. 删除书签 → remove */
{
  const bms = [
    { id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 },
    { id: 'b2', name: 'Google', url: 'https://google.com', cat: 'common', order: 0 },
  ];
  const { p1, t1 } = mirrorTwice([], bms);
  const p = planMirror({
    cats: CATS, rootChildren: t1, folderMap: p1.folderMap, bmMap: p1.bmMap,
    bookmarks: [bms[1]],
  });
  const t = simulate(t1, p.ops);
  eq('11. 删除产生 remove', countOps(p.ops, 'remove'), 1);
  eq('12. 删除后开发分类为空', titles(folder(t, '开发')), []);
  eq('13. 其余书签未受影响', titles(folder(t, '常用')), ['Google']);
}

/* 5. 跨分类移动 → move，不能先删后建（否则丢失节点与位置） */
{
  const bms = [{ id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 }];
  const { p1, t1 } = mirrorTwice([], bms);
  const idBefore = folder(t1, '开发').children[0].id;
  const p = planMirror({
    cats: CATS, rootChildren: t1, folderMap: p1.folderMap, bmMap: p1.bmMap,
    bookmarks: [{ ...bms[0], cat: 'common' }],
  });
  const t = simulate(t1, p.ops);
  eq('14. 跨分类移动零删除', countOps(p.ops, 'remove'), 0);
  eq('15. 跨分类移动零新建', countOps(p.ops, 'create'), 0);
  eq('16. 移动后出现在目标分类', titles(folder(t, '常用')), ['GitHub']);
  eq('17. 移动后源分类清空', titles(folder(t, '开发')), []);
  eq('18. 移动复用同一节点', folder(t, '常用').children[0].id, idBefore);
}

/* 6. 分类重命名 → rename（保留文件夹节点，不重建） */
{
  const bms = [{ id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 }];
  const { p1, t1 } = mirrorTwice([], bms);
  const idBefore = folder(t1, '开发').id;
  const cats2 = CATS.map(c => c.id === 'dev' ? { ...c, name: '开发工具' } : c);
  const p = planMirror({
    cats: cats2, bookmarks: bms, rootChildren: t1,
    folderMap: p1.folderMap, bmMap: p1.bmMap,
  });
  const t = simulate(t1, p.ops);
  eq('19. 分类重命名产生 rename', countOps(p.ops, 'rename'), 1);
  eq('20. 重命名后文件夹标题生效', (folder(t, '开发工具') || {}).title, '开发工具');
  eq('21. 重命名复用同一文件夹节点', (folder(t, '开发工具') || {}).id, idBefore);
  eq('22. 文件夹内书签未丢', titles(folder(t, '开发工具')), ['GitHub']);
}

/* 7. 重排顺序 */
{
  const bms = [
    { id: 'b1', name: 'A', url: 'https://a.com', cat: 'common', order: 0 },
    { id: 'b2', name: 'B', url: 'https://b.com', cat: 'common', order: 1 },
    { id: 'b3', name: 'C', url: 'https://c.com', cat: 'common', order: 2 },
  ];
  const { p1, t1 } = mirrorTwice([], bms);
  eq('23. 初始顺序', titles(folder(t1, '常用')), ['A', 'B', 'C']);
  /* 反转 order */
  const reversed = bms.map((b, i) => ({ ...b, order: 2 - i }));
  const p = planMirror({
    cats: CATS, bookmarks: reversed, rootChildren: t1,
    folderMap: p1.folderMap, bmMap: p1.bmMap,
  });
  const t = simulate(t1, p.ops);
  eq('24. 反转后顺序正确', titles(folder(t, '常用')), ['C', 'B', 'A']);
  eq('25. 重排不产生增删',
    countOps(p.ops, 'create') + countOps(p.ops, 'remove'), 0);
}

/* 8. 同一 URL 出现在不同分类 → 各自保留，互不干扰 */
{
  const bms = [
    { id: 'b1', name: 'MDN', url: 'https://developer.mozilla.org', cat: 'dev', order: 0 },
    { id: 'b2', name: 'MDN 备查', url: 'https://developer.mozilla.org', cat: 'common', order: 0 },
  ];
  const { t1 } = mirrorTwice([], bms);
  eq('26. 重复 URL 在两个分类各存一份',
    [titles(folder(t1, '开发')), titles(folder(t1, '常用'))],
    [['MDN'], ['MDN 备查']]);
}

/* 9. URL 归一化：末尾斜杠差异不应造成重复 */
{
  const bms = [{ id: 'b1', name: 'Example', url: 'https://example.com/', cat: 'common', order: 0 }];
  const { p1, t1 } = mirrorTwice([], bms);
  ok('27. 首轮生成一个书签', (folder(t1, '常用').children || []).length === 1);
  /* OmniHome 侧去掉末尾斜杠 */
  const p = planMirror({
    cats: CATS, rootChildren: t1, folderMap: p1.folderMap, bmMap: p1.bmMap,
    bookmarks: [{ ...bms[0], url: 'https://example.com' }],
  });
  eq('28. 末尾斜杠差异视为同一网址（零新建）', countOps(p.ops, 'create'), 0);
  ok('29. normUrl 忽略末尾斜杠',
    normUrl('https://example.com/') === normUrl('https://example.com'));
}

/* 10. 未知分类 id → 归入未分类，不丢书签 */
{
  const bms = [{ id: 'b1', name: '孤儿', url: 'https://orphan.com', cat: 'ghost', order: 0 }];
  const { t1 } = mirrorTwice([], bms);
  eq('30. 失效分类的书签归入未分类', titles(folder(t1, '未分类')), ['孤儿']);
}

/* 11. 镜像目录里的散落书签（不属于任何分类）应被清理 */
{
  const bms = [{ id: 'b1', name: 'GitHub', url: 'https://github.com', cat: 'dev', order: 0 }];
  const dirty = [
    { id: 'x1', title: '常用', children: [] },
    { id: 'x9', title: '手放的书签', url: 'https://stray.com' },
  ];
  const { t1 } = mirrorTwice(dirty, bms);
  ok('31. 根目录下的散落书签被清理',
    !t1.some(n => n.url), JSON.stringify(t1.map(n => n.title)));
}

/* 12. 「全部」是虚拟分类，不应建文件夹 */
{
  const { t1 } = mirrorTwice([], []);
  ok('32. 未建「全部」文件夹', !folder(t1, '全部'),
    t1.map(n => n.title).join(','));
}

/* ---------- 汇总 ---------- */
console.log(results.join('\n'));
console.log('─'.repeat(46));
console.log(`通过 ${pass} / ${pass + fail}${fail ? '  ✗ 有失败' : '  全部通过'}\n`);
process.exit(fail ? 1 : 0);
