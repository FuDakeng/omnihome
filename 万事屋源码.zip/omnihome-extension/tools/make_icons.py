#!/usr/bin/env python3
"""生成插件图标（纯标准库，无第三方依赖）
图形：靛蓝圆角方块 + 白色书签字形，与万事屋主色 --om-primary (hsl(243 72% 60%)) 一致。
用法：python3 tools/make_icons.py
"""
import struct
import zlib
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "icons"

# hsl(243, 72%, 60%) → RGB(87, 80, 226)
BG = (87, 80, 226)
FG = (255, 255, 255)
SS = 4  # 超采样倍数（抗锯齿）


def rounded_rect_alpha(x, y, w, r):
    """返回点 (x, y) 在边长 w、圆角 r 的圆角矩形内的覆盖判定（返回 True/False）。"""
    if x < 0 or y < 0 or x >= w or y >= w:
        return False
    # 圆角区域：以四个角的圆心判定
    if x < r and y < r:
        return (x - r) ** 2 + (y - r) ** 2 <= r * r
    if x >= w - r and y < r:
        return (x - (w - r - 1)) ** 2 + (y - r) ** 2 <= r * r
    if x < r and y >= w - r:
        return (x - r) ** 2 + (y - (w - r - 1)) ** 2 <= r * r
    if x >= w - r and y >= w - r:
        return (x - (w - r - 1)) ** 2 + (y - (w - r - 1)) ** 2 <= r * r
    return True


def bookmarks_pts(w):
    """书签字形多边形（经典书签：矩形下缘开 V 形缺口）。"""
    gw = 0.40 * w
    x0 = (w - gw) / 2.0
    x1 = x0 + gw
    y0 = 0.22 * w
    y1 = 0.78 * w
    nd = 0.17 * w
    return [(x0, y0), (x1, y0), (x1, y1), (x0 + gw / 2.0, y1 - nd), (x0, y1)]


def in_poly(px, py, pts):
    """射线法判断点是否在多边形内。"""
    inside = False
    n = len(pts)
    j = n - 1
    for i in range(n):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > py) != (yj > py):
            xint = (xj - xi) * (py - yi) / (yj - yi) + xi
            if px < xint:
                inside = not inside
        j = i
    return inside


def render(size):
    """渲染 size×size 的 RGBA 像素（list of rows, each row = list of (r,g,b,a)）。"""
    pts = bookmarks_pts(size)
    radius = 0.22 * size
    step = 1.0 / SS
    rows = []
    for py in range(size):
        row = []
        for px in range(size):
            bg_n = 0
            fg_n = 0
            for sy in range(SS):
                for sx in range(SS):
                    x = px + (sx + 0.5) * step
                    y = py + (sy + 0.5) * step
                    if rounded_rect_alpha(x, y, size, radius):
                        bg_n += 1
                        if in_poly(x, y, pts):
                            fg_n += 1
            total = SS * SS
            if bg_n == 0:
                row.append((0, 0, 0, 0))
                continue
            a_bg = bg_n / total
            a_fg = fg_n / total
            # 先铺背景（含自身 alpha），再按覆盖率把前景叠上去
            r = BG[0] * (1 - a_fg) + FG[0] * a_fg
            g = BG[1] * (1 - a_fg) + FG[1] * a_fg
            b = BG[2] * (1 - a_fg) + FG[2] * a_fg
            row.append((int(round(r)), int(round(g)), int(round(b)),
                        int(round(a_bg * 255))))
        rows.append(row)
    return rows


def write_png(path, rows):
    """写 8 位 RGBA PNG（color type 6），过滤方式 0。"""
    h = len(rows)
    w = len(rows[0])
    raw = bytearray()
    for row in rows:
        raw.append(0)  # filter type: None
        for (r, g, b, a) in row:
            raw += bytes((r, g, b, a))

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", ihdr)
           + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
           + chunk(b"IEND", b""))
    path.write_bytes(png)
    return len(png)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    for size in (16, 32, 48, 128):
        p = OUT / f"icon{size}.png"
        n = write_png(p, render(size))
        print(f"  {p.name:12s} {size}x{size}  {n/1024:.1f} KB")
    print("图标已生成 →", OUT)
