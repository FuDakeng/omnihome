/* ============================================================
   弹窗逻辑：登录 / 连接校验 / 同步控制 / 快速收藏
   ============================================================ */
import { OmniHome, normalizeServer, originPattern } from './lib/api.js';
import { getConfig, setConfig, getSync, clearAuth, ready, DEFAULTS } from './lib/store.js';

const $ = id => document.getElementById(id);
let cfg = null;

/* ---------- 渲染 ---------- */
function fmtTime(ts) {
  if (!ts) return '尚未同步';
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

const DIR_HINT = {
  pull: '把 OmniHome 的分类与顺序镜像到浏览器书签栏下的「{root}」文件夹，只改动该文件夹，不影响你的其它书签。',
  push: '以浏览器「{root}」文件夹为准回写 OmniHome；仅清理插件曾同步过的书签，网页端新增的会保留。',
  both: '双向同步：浏览器端改动先上行，再以 OmniHome 为准下行，冲突时 OmniHome 优先。',
};

async function render() {
  cfg = await getConfig();
  const sync = await getSync();
  const logged = ready(cfg);

  $('paneLogin').hidden = logged;
  $('paneMain').hidden = !logged;
  $('hdSub').textContent = logged
    ? (cfg.user && (cfg.user.nickname || cfg.user.username)) || '已连接'
    : '请先连接你的万事屋';

  const dot = $('dot');
  dot.className = 'dot' + (!logged ? '' : sync.lastError ? ' err' : ' on');
  dot.title = !logged ? '未连接' : sync.lastError ? ('同步异常：' + sync.lastError) : '已连接';

  if (!logged) return;

  $('whoName').textContent = (cfg.user && (cfg.user.nickname || cfg.user.username)) || '—';
  $('whoServer').textContent = cfg.server;
  $('selMode').value = cfg.syncMode;
  $('selDir').value = cfg.direction;
  $('selInterval').value = String(cfg.intervalMin);
  $('inRoot').value = cfg.rootName;
  $('chkNotify').checked = !!cfg.notify;
  $('fldInterval').hidden = cfg.syncMode !== 'timer';
  $('dirHint').textContent = (DIR_HINT[cfg.direction] || '').replace('{root}', cfg.rootName);
  $('syncState').textContent = sync.lastError ? '同步异常' : fmtTime(sync.lastSync);

  const err = $('syncErr');
  if (sync.lastError) {
    err.hidden = false;
    err.textContent = sync.lastError + (/失效|登录/.test(sync.lastError) ? '（请在下方退出后重新登录）' : '');
  } else err.hidden = true;

  await loadCats();
}

async function loadCats() {
  const sel = $('selCat');
  try {
    const api = new OmniHome(cfg.server, cfg.token);
    const cats = (await api.cats()).filter(c => c.id !== 'all');
    const wanted = cats.some(c => c.id === cfg.defaultCat) ? cfg.defaultCat
      : (cats.find(c => c.id === 'common') || cats[0] || {}).id;
    sel.innerHTML = cats.map(c =>
      `<option value="${c.id}"${c.id === wanted ? ' selected' : ''}>${escapeHtml(c.name)}</option>`
    ).join('') || '<option value="none">未分类</option>';
    if (wanted && wanted !== cfg.defaultCat) await setConfig({ defaultCat: wanted });
  } catch (e) {
    sel.innerHTML = `<option value="${cfg.defaultCat || 'common'}">${escapeHtml(cfg.defaultCat || '默认分类')}</option>`;
  }
}

const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- 登录 ---------- */
async function login() {
  const raw = $('inServer').value;
  const server = normalizeServer(raw);
  const username = $('inUser').value.trim();
  const password = $('inPass').value;
  const err = $('loginErr');
  err.hidden = true;

  if (!server) return showLoginErr('请填写有效的服务器地址，如 http://192.168.1.10:8000');
  if (!username || !password) return showLoginErr('请填写用户名和密码');

  const btn = $('btnLogin');
  btn.disabled = true;
  btn.textContent = '连接中…';
  try {
    /* 主机权限必须动态申请：服务器地址由用户决定，不能写死在 manifest 里 */
    const pattern = originPattern(server);
    const granted = await new Promise(res => chrome.permissions.request({ origins: [pattern] }, res));
    if (!granted) return showLoginErr('未授予该地址的访问权限，无法连接');

    const api = new OmniHome(server, '');
    const data = await api.login(username, password);
    if (!data || !data.token) throw new Error('服务端未返回登录凭证');

    await setConfig({
      server, username, token: data.token, user: data.user || null,
      defaultCat: cfg && cfg.defaultCat ? cfg.defaultCat : DEFAULTS.defaultCat,
    });
    $('inPass').value = '';
    await render();
    await chrome.runtime.sendMessage({ type: 'session-changed' });
    /* 首次登录后立刻同步一次，把已有书签拉到浏览器 */
    await doSync();
  } catch (e) {
    showLoginErr(e && e.message ? e.message : String(e));
  } finally {
    btn.disabled = false;
    btn.textContent = '连接并登录';
  }
}
function showLoginErr(msg) {
  const err = $('loginErr');
  err.hidden = false;
  err.textContent = msg;
  return false;
}

/* ---------- 同步 ---------- */
async function doSync() {
  const btn = $('btnSync');
  btn.disabled = true;
  btn.textContent = '同步中…';
  $('syncState').textContent = '正在同步…';
  try {
    const r = await chrome.runtime.sendMessage({ type: 'sync' });
    if (!r || !r.ok) throw new Error((r && r.error) || '同步失败');
    await render();
    if (r.skipped) $('syncState').textContent = '数据无变化';
  } catch (e) {
    const err = $('syncErr');
    err.hidden = false;
    err.textContent = e && e.message ? e.message : String(e);
    await render();
  } finally {
    btn.disabled = false;
    btn.textContent = '立即同步';
  }
}

/* ---------- 快速收藏 ---------- */
async function addCurrent() {
  const btn = $('btnAdd');
  btn.disabled = true;
  try {
    const r = await chrome.runtime.sendMessage({ type: 'add-current', cat: $('selCat').value });
    if (r && !r.ok) {
      const err = $('syncErr');
      err.hidden = false;
      err.textContent = r.error || '收藏失败';
    }
  } finally {
    btn.disabled = false;
    await render();
  }
}

/* ---------- 事件 ---------- */
$('btnLogin').addEventListener('click', login);
$('inPass').addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
$('inServer').addEventListener('keydown', e => { if (e.key === 'Enter') $('inUser').focus(); });
$('inUser').addEventListener('keydown', e => { if (e.key === 'Enter') $('inPass').focus(); });

$('btnSync').addEventListener('click', doSync);
$('btnAdd').addEventListener('click', addCurrent);
$('btnWeb').addEventListener('click', () => chrome.tabs.create({ url: cfg.server }));

$('selMode').addEventListener('change', async e => {
  await setConfig({ syncMode: e.target.value });
  await render();
  await chrome.runtime.sendMessage({ type: 'session-changed' });
});
$('selInterval').addEventListener('change', async e => {
  await setConfig({ intervalMin: Number(e.target.value) });
  await chrome.runtime.sendMessage({ type: 'session-changed' });
});
$('selDir').addEventListener('change', async e => {
  await setConfig({ direction: e.target.value });
  await render();
  await chrome.runtime.sendMessage({ type: 'session-changed' });
});
$('inRoot').addEventListener('change', async e => {
  const name = e.target.value.trim() || DEFAULTS.rootName;
  e.target.value = name;
  await setConfig({ rootName: name });
  await render();
  await doSync();     // 改名后立即重建镜像目录
});
$('chkNotify').addEventListener('change', async e => {
  await setConfig({ notify: e.target.checked });
});
$('btnLogout').addEventListener('click', async () => {
  try {
    const c = await getConfig();
    if (ready(c)) await new OmniHome(c.server, c.token).logout();
  } catch { /* 会话已失效时忽略 */ }
  await clearAuth();
  await chrome.runtime.sendMessage({ type: 'session-changed' });
  await render();
});

render();
