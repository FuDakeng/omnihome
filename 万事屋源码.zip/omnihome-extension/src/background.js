/* ============================================================
   后台服务（MV3 Service Worker）
   职责：右键菜单、定时/变动检测同步、书签变更监听、状态角标、通知。
   ============================================================ */
import { OmniHome } from './lib/api.js';
import { getConfig, getSync, setSync, setConfig, ready } from './lib/store.js';
import { runSync } from './lib/sync.js';

const ALARM_WATCH = 'omni-watch';   // 变动检测：每分钟比对指纹
const ALARM_TIMER = 'omni-timer';   // 定时同步：按配置周期
const MENU_ROOT = 'omni-root';
const MENU_QUICK = 'omni-quick';
const MENU_CAT = 'omni-cat:';

/* 自身写入会触发 bookmark 事件，用一个抑制窗口避免自我循环 */
let suppressUntil = 0;
const suppress = ms => { suppressUntil = Math.max(suppressUntil, Date.now() + ms); };
const suppressed = () => Date.now() < suppressUntil;

/* ---------- 通知 ---------- */
function notify(message, kind = 'ok') {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: '万事屋 OmniHome',
    message: String(message).slice(0, 200),
    priority: kind === 'err' ? 1 : 0,
  });
}

/* ---------- 角标 ---------- */
async function updateBadge() {
  const cfg = await getConfig();
  const sync = await getSync();
  let text = '', color = '#f43f5e';
  if (!ready(cfg)) { text = '!'; color = '#f59e0b'; }
  else if (sync.lastError) { text = '!'; color = '#f43f5e'; }
  await chrome.action.setBadgeText({ text });
  if (text) await chrome.action.setBadgeBackgroundColor({ color });
}

/* ---------- 右键菜单 ---------- */
async function rebuildMenus() {
  await new Promise(res => chrome.contextMenus.removeAll(res));
  const cfg = await getConfig();
  if (!ready(cfg)) return;                       // 未登录不显示菜单

  chrome.contextMenus.create({
    id: MENU_ROOT, title: '添加到万事屋', contexts: ['page', 'link'],
  });
  chrome.contextMenus.create({
    id: MENU_QUICK, parentId: MENU_ROOT,
    title: '快速添加（默认分类）', contexts: ['page', 'link'],
  });

  /* 分类子菜单：分类会随同步变化，每次重建时重新拉取 */
  try {
    const api = new OmniHome(cfg.server, cfg.token);
    const cats = (await api.cats()).filter(c => c.id !== 'all');
    if (cats.length) {
      chrome.contextMenus.create({
        id: 'omni-sep', type: 'separator', parentId: MENU_ROOT, contexts: ['page', 'link'],
      });
      cats.forEach(c => {
        chrome.contextMenus.create({
          id: MENU_CAT + c.id, parentId: MENU_ROOT,
          title: '保存到「' + c.name + '」', contexts: ['page', 'link'],
        });
      });
    }
  } catch { /* 拉不到分类不影响「快速添加」 */ }
}

/* ---------- 收藏当前页 ---------- */
async function addCurrent(url, fallbackTitle, catId) {
  const cfg = await getConfig();
  if (!ready(cfg)) { if (cfg.notify) notify('请先在插件弹窗中登录万事屋', 'err'); return { ok: false }; }

  const api = new OmniHome(cfg.server, cfg.token);
  let name = String(fallbackTitle || '').trim();
  try {
    if (cfg.nameSource === 'site') {
      const meta = await api.siteMeta(url);
      if (meta && meta.name) name = meta.name;
    }
    if (!name) name = new URL(url).hostname;
    const bm = await api.addBookmark({ name, url, cat: catId, desc: '', icon: '', tags: [] });
    if (cfg.notify) notify('已收藏「' + bm.name + '」');
    rebuildMenus();
    return { ok: true, name: bm.name };
  } catch (e) {
    if (e && e.unauthorized) {
      await setSync({ lastError: '登录已失效，请重新登录' });
      if (cfg.notify) notify('登录已失效，请重新登录', 'err');
    } else if (cfg.notify) {
      notify('收藏失败：' + (e && e.message ? e.message : e), 'err');
    }
    updateBadge();
    return { ok: false, error: e && e.message ? e.message : String(e) };
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const url = info.linkUrl || info.pageUrl || (tab && tab.url);
  if (!url || !/^https?:/i.test(url)) {
    notify('当前页面不支持收藏（仅支持 http/https）', 'err');
    return;
  }
  /* 未指定分类时用配置里的默认分类 */
  Promise.resolve(getConfig()).then(cfg => {
    let cat = cfg.defaultCat || 'common';
    if (info.menuItemId && String(info.menuItemId).startsWith(MENU_CAT)) {
      cat = String(info.menuItemId).slice(MENU_CAT.length);
    }
    return addCurrent(url, tab && tab.title, cat);
  });
});

/* ---------- 定时任务 / 变动检测 ---------- */
async function scheduleAlarms() {
  await new Promise(res => chrome.alarms.clearAll(res));
  const cfg = await getConfig();
  if (!ready(cfg)) return;
  if (cfg.syncMode === 'watch') {
    /* Chrome 告警最小周期为 1 分钟，变动检测取这个值 */
    chrome.alarms.create(ALARM_WATCH, { periodInMinutes: 1 });
  } else if (cfg.syncMode === 'timer') {
    const mins = Math.max(5, Math.min(720, Number(cfg.intervalMin) || 30));
    chrome.alarms.create(ALARM_TIMER, { periodInMinutes: mins });
  }
}

chrome.alarms.onAlarm.addListener(a => {
  if (a.name !== ALARM_WATCH && a.name !== ALARM_TIMER) return;
  runSync(a.name === ALARM_WATCH ? 'watch' : 'timer')
    .then(r => {
      if (!r || r.skipped) return;
      rebuildMenus();
      updateBadge();
    })
    .catch(e => {
      /* 401 需要用户重新登录，其余静默等待下个周期，只在角标上体现 */
      updateBadge();
      if (e && e.status === 401) rebuildMenus();
    });
});

/* ---------- 书签变更监听（push / both 模式下回写 OmniHome） ---------- */
async function nodeInMirror(id) {
  const sync = await getSync();
  if (!sync || !sync.rootId) return false;
  if (id === sync.rootId) return true;
  try {
    const tree = await new Promise(res => chrome.bookmarks.getSubTree(sync.rootId, res));
    let found = false;
    (function walk(ns) {
      for (const n of ns) {
        if (n.id === id) { found = true; return; }
        if (n.children) walk(n.children);
      }
    })(tree);
    return found;
  } catch { return false; }
}

let changeTimer = null;
function scheduleChangeSync() {
  clearTimeout(changeTimer);
  changeTimer = setTimeout(async () => {
    if (suppressed()) return;
    const cfg = await getConfig();
    if (!ready(cfg) || cfg.direction === 'pull') return;   // 单向拉取不回写
    try {
      suppress(10000);
      await runSync('change', { force: true });
      rebuildMenus();
      updateBadge();
    } catch { updateBadge(); }
  }, 2500);
}
if (chrome.bookmarks && chrome.bookmarks.onCreated) {
  chrome.bookmarks.onCreated.addListener((id, node) => {
    if (suppressed()) return;
    nodeInMirror(id).then(inside => { if (inside) scheduleChangeSync(); });
  });
  chrome.bookmarks.onRemoved.addListener((id, info) => {
    if (suppressed()) return;
    nodeInMirror(info && info.parentId ? info.parentId : id)
      .then(inside => { if (inside) scheduleChangeSync(); });
  });
  chrome.bookmarks.onChanged.addListener((id) => {
    if (suppressed()) return;
    nodeInMirror(id).then(inside => { if (inside) scheduleChangeSync(); });
  });
  chrome.bookmarks.onMoved.addListener((id) => {
    if (suppressed()) return;
    nodeInMirror(id).then(inside => { if (inside) scheduleChangeSync(); });
  });
}

/* ---------- 弹窗消息 ---------- */
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  const answer = (async () => {
    switch (msg && msg.type) {
      case 'sync':
        try {
          suppress(10000);
          const r = await runSync('manual', { force: true });
          await rebuildMenus();
          await updateBadge();
          return { ok: true, result: r && r.stats ? r.stats : null, skipped: !!(r && r.skipped) };
        } catch (e) {
          await updateBadge();
          return { ok: false, error: e && e.message ? e.message : String(e), status: e && e.status };
        }
      case 'session-changed':
        await scheduleAlarms();
        await rebuildMenus();
        await updateBadge();
        return { ok: true };
      case 'refresh-menus':
        await rebuildMenus();
        return { ok: true };
      case 'add-current': {
        /* 由弹窗触发：收藏当前激活标签页 */
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url) return { ok: false, error: '没有可收藏的页面' };
        return addCurrent(tab.url, tab.title, msg.cat);
      }
      case 'state': {
        const cfg = await getConfig();
        const sync = await getSync();
        return { ok: true, cfg, sync };
      }
      default:
        return { ok: false, error: '未知消息' };
    }
  })();
  answer.then(reply, e => reply({ ok: false, error: String(e && e.message || e) }));
  return true;                                    // 保持异步响应通道
});

/* ---------- 启动 ---------- */
(async function init() {
  await scheduleAlarms();
  await rebuildMenus();
  await updateBadge();
})();

chrome.runtime.onInstalled.addListener(async () => {
  await scheduleAlarms();
  await rebuildMenus();
  await updateBadge();
});
chrome.runtime.onStartup.addListener(async () => {
  await scheduleAlarms();
  await rebuildMenus();
  await updateBadge();
});
